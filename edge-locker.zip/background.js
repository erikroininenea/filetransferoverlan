let blockerActive = true;  // true = blocker på

function updateRules() {
    if(!blockerActive) return; // blocker av = inga regler

    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [1,2,3,4,5,6,7], // ta bort gamla regler först
        addRules: [
            {
                id: 1,
                priority: 1,
                action: { type: "block" },
                condition: { urlFilter: "youtube.com", resourceTypes: ["main_frame"] }
            },
            {
                id: 2,
                priority: 1,
                action: { type: "block" },
                condition: { urlFilter: "crazygames.com", resourceTypes: ["main_frame"] }
            },
            {
                id: 3,
                priority: 1,
                action: { type: "block" },
                condition: { urlFilter: "poki.com", resourceTypes: ["main_frame"] }
            },
            {
                id: 4,
                priority: 1,
                action: { type: "block" },
                condition: { urlFilter: "roblox.com", resourceTypes: ["main_frame"] }
            },
            {
                id: 5,
                priority: 1,
                action: { type: "block" },
                condition: { urlFilter: "opera.com", resourceTypes: ["main_frame"] }
            },
            {
                id: 6,
                priority: 1,
                action: { type: "redirect", redirect: { url: "https://yandex.com" } },
                condition: { urlFilter: "google.", resourceTypes: ["main_frame"] }
            },
            {
                id: 7,
                priority: 1,
                action: { type: "redirect", redirect: { url: "https://yandex.com" } },
                condition: { urlFilter: "bing.com", resourceTypes: ["main_frame"] }
            }
        ]
    });
}

// Kör regler direkt
updateRules();

// Ta emot meddelande från popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if(msg.action === "disable"){
        blockerActive = false;
        // Ta bort blocker-regler
        chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [1,2,3,4,5,6,7]
        });
    }
});

// Kiosk: tvinga startsida även om blocker inaktiverad
chrome.runtime.onStartup.addListener(() => {
    chrome.tabs.create({ url: "newtab.html" });
});

chrome.tabs.onCreated.addListener(tab => {
    if (tab.pendingUrl === "edge://newtab/") {
        chrome.tabs.update(tab.id, { url: "newtab.html" });
    }
});
