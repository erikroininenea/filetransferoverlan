const correctPin = "6892";  // Byt till valfri PIN

document.getElementById("submit").addEventListener("click", () => {
    const pin = document.getElementById("pin").value;
    const msg = document.getElementById("msg");

    if(pin === correctPin){
        // Skicka meddelande till background.js att tillägget ska inaktiveras
        chrome.runtime.sendMessage({action: "disable"});
        msg.style.color = "green";
        msg.innerText = "Blocker inaktiverad!";
    } else {
        msg.innerText = "Fel PIN!";
    }
});
